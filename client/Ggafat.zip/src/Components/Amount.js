import React from 'react'
import './amount.css'

function Amount() {
  return (
    <div className='amount'>
        <div className='am-1'>
             <img src='' alt='' />
             <div className='am-11'>
             <p className='p1'>12+</p>
             <p className='p2'>Year Of Experiance</p>
             </div> 
        </div>
        <div className='am-1'>
             <img src='' alt='' />
             <div className='am-11'>
             <p className='p1'>43+</p>
             <p className='p2'>Our Partners</p>
             </div> 
        </div>
        <div className='am-1'>
             <img src='' alt='' />
             <div className='am-11'>
             <p className='p1'>3148+</p>
             <p className='p2'>Our Employees</p>
             </div> 
        </div>
        <div className='am-1'>
             <img src='' alt='' />
             <div className='am-11'>
             <p className='p1'>16+</p>
             <p className='p2'>Our Stafs</p>
             </div> 
        </div>
    </div>
  )
}

export default Amount