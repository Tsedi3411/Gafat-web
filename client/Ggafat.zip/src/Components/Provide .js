import React from 'react'
import './provide.css'


import image1 from '../assets/police2.jpg'
import image2 from '../assets/police3.jpg'
import image3 from '../assets/plice1.jpg'
import image4 from '../assets/hrm.jpg'


function Provide() {

    const serviceProvide = [
        {
            image: image1,
            title: 'Security Service',
            description: 'Security Service'
        },
        {
            image: image2,
            title: 'Human Resources Service',
            description: 'Providing Human Resources For Different Professions'
        },
        {
            image: image3,
            title: 'Training & Consultancy Service',
            description: 'Training & Consultancy HR & Security Service'
        }, {
            image: image4,
            title: 'Hr Managment Service',
            description: ' provide opportunity of sending to forign Training, Consultancy HR & Security Service and '
        }
        
    ]
    return (
        <div className='provide'>
            <div className='upper-provide'>
                <h1>Service We Provide</h1>
                <p>We provide security and HR services to many prestige companies throughout in ethiopia. For all situations,
                    we are able to supply fully trained and licensed professionals who are also trained in health and safety, first aid,
                    and conflict management. Their focus is to protect the individual, their businesses, property and possessions.</p>
            </div>
           <div className='imagess'>
            {serviceProvide.map(service => (
                <div className='lower-provide'>
                    <img src={service.image} alt='' />
                    <h1>{service.title}</h1>
                    <p>{service.description}</p>
                </div>

            ))}
            </div>
        </div>
    )
}

export default Provide 