import React from 'react'

import im2 from '../assets/plice1.jpg'
import im3 from '../assets/police3.jpg'
import {  NavLink } from 'react-router-dom'
function DetailTwo() {
  const DetailT=[
    {
      image: im2,
      title: 'Recruiting to our Partners',
      Description: 'lorem',
      link:'/news',
    },
  ]
  return ( 
    <div className='detail-two'>
        {DetailT.map(item=>( <div>
          <img src={item.image} alt='Detial two image' />
          <h1>{item.title}</h1>
          <p>{item.Description}</p>
          <NavLink to ={item.link}><button>goback</button></NavLink>
          </div>))}

    </div>
   )
}

export default DetailTwo