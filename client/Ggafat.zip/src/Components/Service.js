import React from 'react'
import './service.css'
import gafatS from '../assets/gafatS.jpg'
import Provide from './Provide '


function Service() {
  return (<>
    <div className='service'>
        <div className='service-left'>
              <img src={gafatS} alt='' />
        </div>
        <div className='service-right'>
              <h1>We Provide Quality Human Resources & Security Services</h1>
             
              <p>Our expertise allows us to design, implement and then maintain highly professional 
                and effective manned security & Human resources strategies.Gafat management team monitors
                 every contract to ensure that the agreed standards are met and provide regular meetings in which
                  to discuss any issues or concerns that may arise.</p>
        </div>
        
    </div>
<Provide />
    </>)
}

export default Service  