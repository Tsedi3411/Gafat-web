import React from 'react'
import { Swiper, SwiperSlide } from 'swiper/react';
// import { Autoplay } from 'swiper';
import 'swiper/swiper-bundle.css'; 

import './home.css'
import image1 from '../assets/gafatS.jpg'
import image2 from '../assets/gafatS.jpg'
import image3 from '../assets/gafatS.jpg'
import ProductShow from './ProductShow';

function Home() {



const slides = [
  {
    image: image1,
    title: 'Slide 1',
    description: 'This is the first slide with a beautiful background.',
  },
  {
    image: image2,
    title: 'Slide 2',
    description: 'This is the second slide with an amazing view.',
  },
  {
    image: image3,
    title: 'Slide 3',
    description: 'This is the third slide showcasing nature.',
  },
];

  return (
    
          <ProductShow/>
    
  )
}

export default Home