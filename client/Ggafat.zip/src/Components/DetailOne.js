import React from 'react'
import im1 from '../assets/hr.jpg'

import { NavLink } from 'react-router-dom'

function DetailOne() {
  const detailOne=[
    {
      image: im1,
      title: 'Give special oportunity to work with forign companies',
      Description: 'lorem',
      link:'/news',
    },
  ]
  return (
    <div className='detail-One'>
         {detailOne.map(item=>(<div>
          <img src={item.image} alt='First Detail Image' />
          <h1>{item.title}</h1>
          <p>{item.Description}</p>
          <NavLink to ={item.link}><button>goback</button></NavLink>
         </div>
         ))}
    </div>
  )
}

export default DetailOne