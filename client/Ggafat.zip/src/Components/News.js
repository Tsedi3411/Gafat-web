import React from 'react'
import './news.css'


import im1 from '../assets/hr.jpg'
import im2 from '../assets/plice1.jpg'
import im3 from '../assets/police3.jpg'
import { Link, NavLink } from 'react-router-dom'

function News() {

  const neews = [
    {
      image: im1,
      title: 'Give special oportunity to work with forign companies',
      Description: 'lorem',
      link:'/DetailO',
    },
    {
      image: im2,
      title: 'Recruiting to our Partners',
      Description: 'lorem',
      link:'/DetailT',
    },
    {
      image: im3,
      title: 'Get an Award from Federal managment center',
      Description: 'lorem',
      link:'/DetailTh',
    },
  ]

  return (
    <div className='news'>
      <div className='upper-news'>
        <h1>Our Latest News</h1>
        <p>Follow Us To Get Our Latest News and Updated Information!</p>
      </div>
      <div className='latest-news'>
        {neews.map((item,index)=>(
          <div className='neews'>
            <NavLink to ={item.link} key={index}>
            <img src={item.image} alt='' /></NavLink>
            <h2>{item.title}</h2>
            <p>{item.Description}</p>
            <button>{item.detail}</button>
            
          </div>
        ))}
      </div>

      <div>

      </div>

    </div>
  )
}

export default News