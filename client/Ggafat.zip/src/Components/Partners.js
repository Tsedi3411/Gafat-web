import React from 'react'
import './partners.css'
import a from '../assets/abay-bank.jpg'
import ab from '../assets/Abyssinia-bank.png'
import an from '../assets/anbesa-bank.png'
import b from '../assets/bherawi.jpg'
import bu from '../assets/buna-bank.png'
import e from '../assets/Enat-bank.jpg'
import k from '../assets/keyizen.jpg'
import o from '../assets/oromya-bank.png'
import t from '../assets/tsedey.png'

function Partners() {
  return (
    <div className='partners'>
        <div className='part-1'>
             <h1>Our Partners</h1>
             <p>Our best partnerships are not dependent on a more common goal but on a shared path of equality, desire, and no small amount of passion.</p>
        </div>
        <div className='part-2'>
              <img className='ima part-21' src={a} alt='' />
              <img className=' ima part-22' src={ab} alt='' />
              <img  className='ima part-23' src={an} alt='' />
              <img className='ima part-24' src={b} alt='' />
              <img className='ima part-25' src={bu} alt='' />
              <img className='ima part-26' src={e} alt='' />
              <img className='ima part-27' src={k} alt='' />
              <img className='ima part-28' src={o} alt='' />
              <img className='ima part-29' src={t} alt='' />
        </div>
    </div>
  )
}

export default Partners