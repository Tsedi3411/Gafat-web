import React from 'react'
import './about.css'

function About() {
  return (
    <div className='about'>
      <div className='vision'>
        <h1>Vision</h1>
        <ul>

          <li>Our vision is to create a workplace where diversity is celebrated,
            collaboration is the norm, and every employee is inspired to reach their highest potential</li>
          <li>To be a leading HR organization recognized for our commitment
            to innovation, excellence, and the empowerment of every employee, shaping a future where talent thrives.</li>
          <li>
            To transform the employee experience by fostering a culture of trust, engagement, and
            continuous improvement, positioning our organization as an employer of choice.
          </li>
          <li>
            We envision a future where every employee feels valued and connected, driving organizational
            success through a culture of inclusivity and shared purpose.
          </li>
          <li>To lead the way in human resources by embracing innovative practices that enhance employee satisfaction, 
            drive performance, and build a resilient workforce for the future.</li>
        </ul>
      </div>
      <div className='mission'>
        <h1>Mission</h1>
        <ul>

          <li>Our mission is to attract, develop, and retain top talent by creating a supportive and
            innovative environment where employees can thrive, contribute, and achieve their full potential.</li>
          <li>To empower our workforce through inclusive practices, fostering a culture of collaboration
            and continuous growth, while championing the well-being and development of every employee.</li>
          <li>
            To cultivate a dynamic workplace that values diversity, drives engagement, and inspires excellence,
            ensuring that every employee feels valued and empowered to succeed.
          </li>
          <li>
            We are committed to building a sustainable and inclusive organizational culture that prioritizes
            employee well-being, professional growth, and a sense of belonging for all.
          </li>
        </ul>

      </div>

    </div>
  )
}

export default About