import { createBrowserRouter } from "react-router-dom";
import Layout from "./Layout";
import Home from "./Components/Home";
import Partners from "./Components/Partners";
import News from "./Components/News";
import About from "./Components/About";
import Service from "./Components/Service";
// import path from "path";
import DetailOne from "./Components/DetailOne";
import DetailTwo from "./Components/DetailTwo";
import DetailThree from "./Components/DetailThree";
import Contact from "./Components/Contact";
import Vacancy from "./Components/Vacancy";



const router = createBrowserRouter([
    {
      path: "/",
      element: <Layout />,
      children: [
        {
          path: "/",
          element: <Home />,
        },
        {
            path: "/about",
            element: <About/>,
          },
          {
            path: "/service",
            element: <Service />,
          },
          {
            path:"/news",
            element: <News />
        },
        {
           path:"/contact",
           element:<Contact />
        },
        {
            path:'/vacancy',
            element:<Vacancy />
        },

        {
          path: "/partner",
          element: <Partners />,
        },
        {
            path:'/DetailO',
            element:<DetailOne />
        },
        {
          path:'/DetailT',
          element:<DetailTwo />
      },
      {
        path:'/DetailTh',
        element:<DetailThree />
    },
       
    ],
},
]);
export default router;